const express = require('express');
const cors = require('cors');
const { OpenAI } = require('openai');
const pdf = require('html-pdf');
require('dotenv').config();

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// ===== Test Endpoint =====
app.get('/', (req, res) => {
  res.send('Smart Resume Builder Backend');
});

// ===== Basic Suggestions (Mocked AI) =====
app.post('/api/ai-suggestions', (req, res) => {
  const { summary, education, experience, skills } = req.body;

  const suggestions = `✨ Here's a suggestion:
- Emphasize your skills in ${skills || 'varied domains'}.
- Tailor your experience "${experience}" to match your goals.
- Enhance your summary to express your enthusiasm as a fresher.`;

  res.json({ suggestions });
});

// ===== OpenAI Integration =====
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.post('/api/suggestions', async (req, res) => {
  try {
    const { summary, experience, education, skills } = req.body;

    if (!summary && !experience && !education && !skills) {
      return res.status(400).json({ error: 'No resume content provided' });
    }

    const prompt = `
You are a professional resume consultant.

Summary: ${summary || 'Not provided'}
Experience: ${experience || 'Not provided'}
Education: ${education || 'Not provided'}
Skills: ${skills || 'Not provided'}

Give 5-8 resume improvement tips. Focus on:
- Stronger action verbs
- Quantifiable achievements
- ATS keyword optimization
- Formatting tips
`;

    const aiResponse = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: 'You are a certified resume expert. Respond with concise, actionable advice.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 350
    });

    res.json({
      suggestions: aiResponse.choices[0].message.content
    });

  } catch (error) {
    console.error('OpenAI Error:', error.message);
    res.status(500).json({ error: 'Failed to process request' });
  }
});

// ===== PDF Generation =====
app.post('/api/generate-pdf', (req, res) => {
  const htmlContent = req.body.html;

  const options = {
    format: 'A4',
    border: {
      top: '20px',
      right: '20px',
      bottom: '20px',
      left: '20px'
    }
  };

  pdf.create(htmlContent, options).toBuffer((err, buffer) => {
    if (err) return res.status(500).json({ error: err.message });

    res.setHeader('Content-Type', 'application/pdf');
    res.send(buffer);
  });
});

app.listen(PORT, () => {
  console.log(`✅ Backend is running at http://localhost:${PORT}`);
});